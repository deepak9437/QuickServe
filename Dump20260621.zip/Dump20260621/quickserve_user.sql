-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: quickserve
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `pincode` int DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'QuickServe','$2a$10$j/VMAeTONv1sWyTQHHOo1.tYE7r/JPrTkhTPmN1IHDQmfAQWDjLXC','male','orders.quickserve@gmail.com','BBSR',NULL,'admin','9437550595','2026-06-07 13:48:49'),(2,'Rohit Sharma','$2a$10$gDTEtbW6501G3tBttwmrse5jvpuX9Wr0JoSNJJTkJTdbC.IKWYdZ2','male','rohit@gmail.com','Kolkata',756425,'customer','1234567890','2026-06-09 12:27:36'),(4,'Subman gill','$2a$10$JBKOgdVK9yyP6OltneDAOeqK93HojoNsWK0qiPHhBlXwXmUpruVh2','male','gill@gmail.com','Punjab',567520,'customer','9876543210','2026-06-09 12:31:38'),(5,'Virat Kohli','$2a$10$0ACl4vi7ELQMEv2bSzf1lO2uQR3R8lIRp63HbdYsRp96L6szxA6mq','male','virat@gmail.com','Delhi',756544,'customer','6549873210','2026-06-09 12:32:38'),(6,'Narendra Modi','$2a$10$MpX1v1KyelflaxCwqaRmw.xu.uKbtTxpDnEBQVkuRKIeS.VBwAMae','Male','modi@gmail.com','Ahmadabad,Gujurat',756644,'provider','7896541230','2026-06-09 12:35:21'),(7,'Rahul Gandhi','$2a$10$guZzDih2nLih9u/eisd89./w..SDGRuGNHfT8EDlU2v.p8uAQZm9m','Male','rahul@gmail.com','Delhi,758560',754519,'provider','7896543210','2026-06-09 12:37:17'),(8,'Naveen Pattnayak','$2a$10$f.c807kPT2MHkaYVekqt5e0eUXQ.a.CHq0UdBRwdEYR0tDJILv4hu','Male','naveen@gmail.com','Odisha,bbsr',750000,'provider','9513574560','2026-06-09 12:39:37'),(9,'Mohan Majhi','$2a$10$Dijoj/kf2Yu79ufaXIiyZ.w/0GTMU1A6IhQr5L3hu3s/OVqhD5YUu','Male','mohan@gmail.com','Odisha,keonjhar',756242,'provider','8657230152','2026-06-09 12:43:40'),(10,'Shikhar Dhawan','$2a$10$0km1uU6gUMvDmxNDsnEbCOtpJCis3pDB1QqOCv3XWUWQS5m0OYFvq','Male','shikhar@gmail.com','Punjab',754585,'provider','7896543210','2026-06-09 12:48:58'),(11,'Ishan kishan','$2a$10$lOrqyrLeQo2h2CTEudUOCuD.C22mIuPyYFK336auaSg8wz.4o8D4e','Male','ishan@gmail.com','Bihar',756344,'provider','9638527410','2026-06-09 12:50:39'),(12,'smriti mandhana','$2a$10$rMk6hF3d8wHanGNMBMdnx.jh9iLcRvgIbdeUPVoDHlCMZxJ1GA/W.','Female','smriti@gmail.com','Bangalore',754564,'provider','7418520963','2026-06-09 12:52:38'),(13,'Sunil chhetr','$2a$10$GP7pQdKTzWZjzQzQeg0.QeypjP2wfDoxhistPggmxT1x/NBfcTzPC','Male','sunil@gmail.com','Bangalore',758520,'provider','7896352410','2026-06-09 14:47:13'),(14,'Jatin Sapru','$2a$10$oyItycAfKGA85KH.TXvhkOw/B3v6O9lYLFadBOFe7XbTHX0nTQdNu','male','jatin@gmail.com','Hyderabad',754520,'customer','9874563201','2026-06-11 01:51:35');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-21 11:39:29
