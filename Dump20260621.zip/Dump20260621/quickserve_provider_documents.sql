-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: quickserve
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `provider_documents`
--

DROP TABLE IF EXISTS `provider_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_documents` (
  `pd_id` int NOT NULL AUTO_INCREMENT,
  `p_id` int DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `document_url` varchar(50) DEFAULT NULL,
  `certificate` varchar(50) DEFAULT NULL,
  `extra_certificate` varchar(50) DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pd_id`),
  KEY `p_id` (`p_id`),
  CONSTRAINT `provider_documents_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `provider` (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_documents`
--

LOCK TABLES `provider_documents` WRITE;
/*!40000 ALTER TABLE `provider_documents` DISABLE KEYS */;
INSERT INTO `provider_documents` VALUES (1,1,'Voter ID','Screenshot 2025-02-20 231944.png','Screenshot 2025-09-14 113952.png','Screenshot 2025-09-25 104926.png','2026-06-09 12:35:21'),(2,2,'Aadhaar Card','Screenshot 2026-05-21 211427.png','Screenshot 2026-06-01 215911.png','Screenshot 2026-06-06 195650.png','2026-06-09 12:37:17'),(3,3,'PAN Card','Screenshot 2026-05-17 084953.png','Screenshot 2026-06-09 113034.png','Screenshot 2026-06-06 195650.png','2026-06-09 12:39:37'),(4,4,'Aadhaar Card','Screenshot 2026-05-22 080431.png','Screenshot 2026-05-27 183533.png','Screenshot 2025-09-25 104926.png','2026-06-09 12:43:40'),(5,5,'Driving License','Screenshot 2026-05-21 211427.png','Screenshot 2026-05-17 084953.png','Screenshot 2025-02-20 231944.png','2026-06-09 12:48:58'),(6,6,'PAN Card','Screenshot 2026-06-07 093757.png','Screenshot 2026-05-22 080431.png','Screenshot 2026-05-21 211427.png','2026-06-09 12:50:39'),(7,7,'Aadhaar Card','Screenshot 2025-02-20 231944.png','Screenshot 2025-09-14 113952.png','Screenshot 2025-09-25 104926.png','2026-06-09 12:52:38'),(8,8,'Driving License','Screenshot 2025-09-14 113952.png','Screenshot 2025-02-20 231944.png','Screenshot 2025-09-25 104926.png','2026-06-09 14:47:13');
/*!40000 ALTER TABLE `provider_documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-21 11:39:29
